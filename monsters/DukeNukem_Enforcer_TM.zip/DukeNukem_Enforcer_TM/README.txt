Duke Nukem Sprite Replacement Model 

 E N F O R C E R

Model, skins and animations by Tea Monster. 
Ice Model and definitions created by Spiker

Commercial use prohibited. See licence.txt for details. 

Originally appeared in the Hollywood Holocaust Rethinked mod.

https://www.moddb.com/mods/hollywood-holocaust-rethinked

Tea Monster can be contacted at tea_monster (at) yahoo.com

This file contains:

The Blender creation file
Textures in PBR Metallic and Spec/Gloss formats
Textures for EDuke32's Polymer Renderer
MD3 models for EDuke32

There is a muzzle flash graphic that is part of the Duke Nukem High Res Pack that we used for the Enforcer model. We are not allowed to distribute this graphic as I did not create it. Please see the Duke Nukem HRP for this file. 